-- 1) Seleziona la matricola,nome e cognome dei dipendenti ordinati per nome, 
-- il quale inzia per la lettera m oppure per f ed il cognome che inizia per g

SELECT Matricola,Nome,Cognome
FROM Dipendente
WHERE (Nome like "M%" or Nome like "F%") and Cognome like "G%"
ORDER BY (Nome);

-- 2) Stampare la tipologia dell'attività ed il codice del collo, 
-- che dovranno essere consegnati nel mese di gennaio 2022

SELECT E.Tipo,C.IDCollo
FROM EsercizioCommerciale as E join Collo as C on E.PIVA=C.PIVA
WHERE C.DataConsegna>="2022-01-01" and C.DataConsegna<="2022-01-31";

-- 3) Selezionare lo stipendio totale di tutti i dipendenti

SELECT SUM(D.Stipendio) as "Stipendio totale"
FROM Dipendente as D;

-- 4) Per ogni reparto, selezionare la relativa sommma 
-- degli stipendi dei dipendenti

SELECT SUM(D.Stipendio) as "Stipendio",R.Nome
FROM (Dipendente as D join Lavorare as L on D.Matricola=L.MatricolaDip) 
join Reparto as R on R.IDReparto=L.IDReparto
GROUP BY (R.IDReparto);


-- 5) Stampare i nome dei reparti, dove lavorano più di 5 dipendenti

SELECT R.Nome,COUNT(R.IDReparto) as "Reparto"
FROM  Lavorare as L join Reparto as R on L.IDReparto=R.IDReparto
GROUP BY (R.IDReparto)
HAVING COUNT(R.IDReparto)>=5;

-- 6) Elencare il nome del reparto, che possiede lo stipendio maggiore
SELECT R.Nome,SUM(D.Stipendio) as "Stipendio"
FROM (Dipendente as D join Lavorare as L on L.MatricolaDip=D.Matricola) 
join Reparto as R on R.IDReparto=L.IDReparto
GROUP BY(R.IDReparto) 
HAVING SUM(D.Stipendio) >= ALL (SELECT SUM(D1.Stipendio)
						FROM Dipendente as D1 join Lavorare as L1 on L1.MatricolaDip=D1.Matricola
                        GROUP BY(L1.IDReparto));


-- 7) Selezionare la tipologia degli esercizi commerciali ed il relativo nome dei proprietari,
-- che non hanno merce in consegna per il mese di gennaio dell'anno 2022

SELECT E.Tipo,P.Nome
FROM EsercizioCommerciale as E join Proprietario as P on P.CF=E.CFProprietario
WHERE E.PIVA NOT IN ( SELECT C.PIVA
                FROM Collo as C 
                WHERE  C.PIVA=E.PIVA and C.DataConsegna>="2022-01-01" 
                and C.DataConsegna<="2022-01-31");


-- 8) Selezionare la matricola ed il nome di tutti i dipendenti, che 
-- lavorano nel reparto "Area Clienti"

SELECT D.Matricola,D.Nome
FROM Dipendente as D
WHERE NOT EXISTS (SELECT *
					FROM Reparto as R
                    WHERE R.Nome="Area Clienti"
                    and NOT EXISTS(SELECT *
									FROM Lavorare as L
                                    WHERE D.Matricola=L.MatricolaDip and L.IDReparto=R.IDReparto));   
                                    