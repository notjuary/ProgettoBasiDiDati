drop database if exists HubRaccolta;
create database HubRaccolta;
use HubRaccolta;


create table Dipendente(
Matricola char(5) primary key,
Nome varchar(30) not null,
Cognome varchar(30) not null,
CF varchar(30) not null,
Stipendio double,
DataAssunzione date,
MesiContratto int
);

create table Reparto(
IDReparto char(5) primary key,
Nome varchar(20) not null,
Posizione varchar(20)
);

create table Lavorare(
MatricolaDip char(5),
IDReparto char(5),
primary key(MatricolaDip,IDReparto),
foreign key (MatricolaDip) references Dipendente(Matricola),
foreign key (IDReparto) references Reparto(IDReparto)
);

create table Telefono(
NumeroReparto char(10) primary key,
IDReparto char(5),
foreign key (IDreparto) references Reparto(IDreparto)
);

create table Proprietario(
CF char(16) primary key,
Nome varchar(20),
Cognome varchar(20)
);

create table EsercizioCommerciale(
PIVA char(11) primary key,
Tipo varchar(30),
Via varchar(30),
Civico int,
CAP int,
CFProprietario char(16) not null,
foreign key(CFProprietario) references Proprietario(CF)
);

create table Collo(
IDCollo char(5) primary key,
Lunghezza int,
Larghezza int,
Peso int,
Altezza int,
Volume int,
IDReparto char(5),
PIVA char(11),
DataConsegna date,
foreign key(IDReparto) references Reparto(IDReparto),
foreign key(PIVA) references EsercizioCommerciale(PIVA)
);


insert into Dipendente values
("D0001","Giuseppe","Musso","KBBNLC73L51A945L",1500,"2010-02-02",null),
("D0002","Maria","Serrato","HSPKXN65M14D660D",1000,"2015-10-15",null),
("D0003","Andrea","Ferrero","VGSVVF54B05L809P",1200,"2013-08-01",null),
("D0004","Roberto","Bianco","TTKGTT94S21E438S",2000,"2005-01-07",null),
("D0005","Fabio","Gamba","PSLSBT88D65E687D",1300,"2019-10-15",null), 
("D0006","Flora","Bossio","BPDGDL88E48I163W",null,null,6),
("D0007","Orlando","Grassi","GBTRVR97M64E893S",null,null,7),
("D0008","Valentina","Foa","SGZYTJ93L68G628B",null,null,8),
("D0009","Martino","Veltroni","VDNBDT93S69D207S",null,null,10),
("D0010","Ivan","Grassi","BFVRZE44D43C771M",null,null,4),
("D0011","Federico","Gatto","PSLSBT88D65E612Q",1100,"2021-11-10",null), 
("D0012","Fabrizio","Generoso","BPDGDL88E48I174L",null,null,3),
("D0013","Maurizio","Gaglione","GPHSBT88D65E612Q",2500,"2001-01-10",null), 
("D0014","Maria","Garibaldi","MGBGDL88E48I174L",null,null,10),
("D0015","Alfredo","Petulla","GPHSBT73K65E612Q",1500,"2010-01-10",null),
("D0016","Mario","Fossetto","MGBGDL88E70P174L",null,null,2),
("D0017","Renato","Esposito","MGBGDL74L70P174L",null,null,12),
("D0018","Carmelo","Esposito","PSLSBT88D80K687D",1500,"2014-01-14",null), 
("D0019","Alessandro","Borghese","PSLSBT91P65E687D",1700,"2010-09-11",null), 
("D0020","Sigfrido","Coppola","MLOSBT88D65E687D",1500,"2016-07-15",null);

insert into Reparto values
("R0001","Smistamento","Esterna"),
("R0002","Spedizione","Esterna"),
("R0003","Logistico","Interna"),
("R0004","Area Clienti","Intera");

insert into Lavorare values
("D0001","R0002"), 
("D0002","R0003"), 
("D0003","R0001"), 
("D0004","R0004"), 
("D0005","R0002"),
("D0006","R0002"), 
("D0007","R0003"),
("D0008","R0004"), 
("D0009","R0001"), 
("D0010","R0004"), 
("D0011","R0001"), 
("D0012","R0003"), 
("D0013","R0004"), 
("D0014","R0002"), 
("D0015","R0003"), 
("D0016","R0002"),
("D0017","R0003"),
("D0018","R0002"),
("D0019","R0002"),
("D0020","R0002");

insert into Telefono values
("0818139867","R0001"),
("0817678342","R0002"),
("0811416109","R0003"),
("0814125629","R0004");

insert into Proprietario values
("BPBMFM85H68L709L","Eugenia","Caracciolo"), 
("FNZCDM63D48G324M","Claudio","Trapani"), 
("TGEWLX68C57M060S","Ermenegildo","Magrassi"), 
("SDVPNP62B23A792C","Ennio","Druso"),
("XHSRMH52B21B178A","Annunziata","Vespucci"), 
("PQMVSZ76T22G474O","Sabatino","Santoro"), 
("CUUQFR33R66F917O","Ermanno","Veltroni"), 
("NNLRDR58D51A709T","Carla","Riccati-Blasi"), 
("ZPOLMT79P67A360Y","Domenico","Falco"), 
("QXMLGT93L87P923Z","Francesco","Barlotti"),
("FNZCDM63D48G379X","Aldo","Moro");

insert into EsercizioCommerciale values
("86334519757","Abbigliamento","Via Corrado Buono",6,80070,"BPBMFM85H68L709L"),
("36570141204","Informatica","Piazza Municipio",10,80030,"ZPOLMT79P67A360Y"),
("36573147283","Informatica","Via Aldo Moro",1,80040,"QXMLGT93L87P923Z"),
("69516270639","Profumeria","Via Libertà",12,80079,"CUUQFR33R66F917O"),
("45721810856","Articoli Sportivi","Via Enrico De Nicola",6,80070,"SDVPNP62B23A792C"),
("17196400604","Supermercato","Via Emanuele II",4,80010,"XHSRMH52B21B178A"),
("54951410668","Ristorante","Via Napolitano",38,83045,"NNLRDR58D51A709T"),
("64196160754","Gelateria","Via Gramsci",10,83456,"PQMVSZ76T22G474O"),
("16858770635","Pasticceria","Piazza Giovanni XXIII",13,80053,"TGEWLX68C57M060S"),
("68404690635","Farmacia","Via Vittorio Veneto",15,80054,"FNZCDM63D48G324M"),
("68404690743","Informatica","Via D-Andrea",10,83026,"FNZCDM63D48G379X");

insert into Collo values
("C0001",25,40,100,50,Lunghezza*Larghezza*Altezza,"R0001","86334519757","2022-01-23"),
("C0002",40,20,300,15,Lunghezza*Larghezza*Altezza,"R0003","36570141204","2022-01-01"),
("C0003",33,24,100,12,Lunghezza*Larghezza*Altezza,"R0002","36573147283","2022-01-07"),
("C0004",44,25,150,17,Lunghezza*Larghezza*Altezza,"R0001","69516270639","2022-01-25"),
("C0005",50,35,250,170,Lunghezza*Larghezza*Altezza,"R0001","45721810856","2022-01-30"),
("C0006",33,79,345,80,Lunghezza*Larghezza*Altezza,"R0002","17196400604","2022-02-05"),
("C0007",22,90,70,35,Lunghezza*Larghezza*Altezza,"R0002","54951410668","2022-02-01"),
("C0008",49,62,29,144,Lunghezza*Larghezza*Altezza,"R0003","64196160754","2022-01-10"),
("C0009",5,35,29,15,Lunghezza*Larghezza*Altezza,"R0003","16858770635","2022-01-31"),
("C0010",34,200,685,94,Lunghezza*Larghezza*Altezza,"R0003","68404690635","2022-02-01"),
("C0011",40,20,300,15,Lunghezza*Larghezza*Altezza,"R0001","68404690743","2022-02-01");