import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTextArea;

public class InserimentoFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JComboBox comboBox_1 = new JComboBox();
	private static final String DB_URL="jdbc:mysql://localhost:3306/hubraccolta";
	private static final String USER="root";
	private static final String PASS="Mercogliano2021!";
	private JTextArea textArea = new JTextArea();
	
	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InserimentoFrame frame = new InserimentoFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InserimentoFrame() {
		setTitle("Inserimento nuovo collo");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 659, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new MigLayout("", "[][grow]", "[][][][][grow][][]"));
		
		JLabel lblNewLabel = new JLabel("IDCollo");
		panel.add(lblNewLabel, "cell 0 0,alignx trailing");
		
		textField = new JTextField();
		panel.add(textField, "flowx,cell 1 0,alignx left");
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Lunghezza");
		panel.add(lblNewLabel_1, "cell 1 0");
		
		textField_1 = new JTextField();
		panel.add(textField_1, "cell 1 0");
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Larghezza");
		panel.add(lblNewLabel_2, "cell 1 0");
		
		textField_2 = new JTextField();
		panel.add(textField_2, "cell 1 0");
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Peso");
		panel.add(lblNewLabel_3, "cell 0 2,alignx trailing");
		
		textField_3 = new JTextField();
		panel.add(textField_3, "flowx,cell 1 2,alignx left");
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Altezza");
		panel.add(lblNewLabel_4, "cell 1 2");
		
		textField_4 = new JTextField();
		panel.add(textField_4, "cell 1 2");
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Selezione reparto");
		panel.add(lblNewLabel_7, "cell 1 2");
		
		
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"R0001", "R0002", "R0003"}));
		panel.add(comboBox_1, "cell 1 2");
		
		JButton btnNewButton = new JButton("Inserimento");
		btnNewButton.addMouseListener(new MouseAdapter() {
		
			public void mouseClicked(MouseEvent e) {
				Connection dbConnection=null;
				textArea.setText("");
				try {
					disableWarning();

					dbConnection= (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
					if(dbConnection!=null)
						System.out.println("Connessione effettuata con successo a: "+DB_URL);            
				}catch(SQLException e1) {
					System.out.println("Connessione non riuscita a: "+DB_URL);
					e1.printStackTrace();
				}
				
				
				try {
					Statement stmt;
					stmt = dbConnection.createStatement();
					
					String id=textField.getText();
					int lunghezza=Integer.parseInt(textField_1.getText());
					int larghezza=Integer.parseInt(textField_2.getText());
					int peso=Integer.parseInt(textField_3.getText());
					int altezza=Integer.parseInt(textField_4.getText());
					
					int volume=lunghezza*altezza*larghezza;
					String reparto=(String) comboBox_1.getSelectedItem();
					String data="2022-03-01";
					String PIVA="68404690635";
					String sql="INSERT INTO Collo(IDCollo,Lunghezza,Larghezza,Peso,Altezza,Volume,IDReparto)"+"VALUES('"+id+"','"+lunghezza+"','"+larghezza+"','"+peso+"','"+altezza+"','"+volume+"','"+reparto+"')";
					String sql1="INSERT INTO Consegnare(IDCollo,PIVA,DataConsegna)"+"VALUES('"+id+"','"+PIVA+"','"+data+"')";
					stmt.executeUpdate(sql);
					stmt.executeUpdate(sql1);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				String result="Select IDCollo,Lunghezza,Larghezza,Peso,Altezza,Volume,IDReparto FROM Collo";
				Statement stmt1;
				try {
					stmt1 = dbConnection.createStatement();
					ResultSet rs=stmt1.executeQuery(result);
					
					while(rs.next()) {
						textArea.append("IDCollo "+rs.getString("IDCollo")+" Lunghezza: "+rs.getShort("Lunghezza")+" Larghezza: "+rs.getString("Larghezza")+" Peso: "+rs.getString("Peso")+" Altezza: "+rs.getString("Altezza")+" Volume: "+rs.getString("Volume")+" IDReparto: "+rs.getString("IDReparto")+"\n");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				JOptionPane.showMessageDialog(null, "Inserimento avvenuto con successo");
			}
		});
		panel.add(btnNewButton, "cell 1 2,alignx right");
		
		JLabel lblNewLabel_8 = new JLabel("Leggenda: R0001= Smistamento, R0002= Spedizione, R0003=Logistico");
		panel.add(lblNewLabel_8, "cell 1 3,alignx left");
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, "cell 0 4 2 3,grow");
		panel_1.setLayout(new MigLayout("", "[grow][]", "[grow][]"));
		
		
		panel_1.add(textArea, "cell 0 0 2 2,grow");
	}

}
