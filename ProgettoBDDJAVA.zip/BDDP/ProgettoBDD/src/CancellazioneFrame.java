import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTextArea;

public class CancellazioneFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private static final String DB_URL="jdbc:mysql://localhost:3306/hubraccolta";
	private static final String USER="root";
	private static final String PASS="Mercogliano2021!";
	private JTextArea textArea = new JTextArea();
	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CancellazioneFrame frame = new CancellazioneFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CancellazioneFrame() {
		setTitle("Cancellazione collo");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 896, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new MigLayout("", "[][][grow][grow]", "[][][][grow]"));
		
		JLabel lblNewLabel = new JLabel("IDCollo");
		panel.add(lblNewLabel, "cell 2 2,alignx trailing");
		
		textField = new JTextField();
		panel.add(textField, "flowx,cell 3 2,alignx left");
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Cancella");
		btnNewButton.addMouseListener(new MouseAdapter() {
		
			public void mouseClicked(MouseEvent e) {
				Connection dbConnection=null;
				textArea.setText("");
				try {
					disableWarning();

					dbConnection= (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
					if(dbConnection!=null)
						System.out.println("Connessione effettuata con successo a: "+DB_URL);            
				}catch(SQLException e1) {
					System.out.println("Connessione non riuscita a: "+DB_URL);
					e1.printStackTrace();
				}
				
				String id=textField.getText();
				String sql = "DELETE FROM Consegnare "+" WHERE IDCollo= '"+id+"';";
				//String sql2 = "DELETE FROM Consegnare " +"WHERE IDCollo = '"+id+"';";
				//Statement stmt2;
				//String sql="DELETE FROM Dipendente "+" WHERE Dipendente.Matricola= '"+id+"';";
				
				Statement stmt;
				try {
					stmt = dbConnection.createStatement();
					stmt.executeUpdate(sql);
					//stmt2 = dbConnection.createStatement();
					//stmt2.executeUpdate(sql2);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
				String result="SELECT IDCollo,PIVA,DataConsegna FROM Consegnare ORDER BY (IDCollo)";
				
				Statement stmt1;
				try {
					stmt1 = dbConnection.createStatement();
					ResultSet rs=stmt1.executeQuery(result);
					
					while(rs.next()) {
						
						textArea.append("IDCollo: "+rs.getString("IDCollo")+" PIVA: "+rs.getString("PIVA")+" Data Consegna: "+rs.getString("DataConsegna")+"\n");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				JOptionPane.showMessageDialog(null, "Cancellazione avvenuta con successo");
			
			}
		});
		panel.add(btnNewButton, "cell 3 2");
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, "cell 0 3 4 1,grow");
		panel_1.setLayout(new MigLayout("", "[][][][][][][grow]", "[][grow]"));
		textArea.setEditable(false);
		
		
		panel_1.add(textArea, "cell 0 0 7 2,grow");
	}

}
