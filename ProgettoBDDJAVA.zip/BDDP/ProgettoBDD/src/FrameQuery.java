import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButtonMenuItem;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class FrameQuery extends JFrame {

	private JPanel contentPane;
	private static final String DB_URL="jdbc:mysql://localhost:3306/hubraccolta";
	private static final String USER="root";
	private static final String PASS="Mercogliano2021!";
	private JTextArea textArea = new JTextArea();
	private static InserimentoFrame ins=new InserimentoFrame();
	private CancellazioneFrame cf=new CancellazioneFrame();
	private ModificaFrame mf=new ModificaFrame();
	private VisualizzazioneFrame vf=new VisualizzazioneFrame();
	/**
	 * Launch the application.
	 */
	
	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameQuery frame = new FrameQuery();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrameQuery() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 814, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Men\u00F9");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Inserimento");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ins.setVisible(true);
			
			
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Cancellazione");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cf.setVisible(true);
			
			}
		});
		mntmNewMenuItem_1.addMouseListener(new MouseAdapter() {
			
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Modifica");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.setVisible(true);
			
			}
		});
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Visualizzazione");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vf.setVisible(true);
			
			
			}
		});
		mnNewMenu.add(mntmNewMenuItem_3);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new MigLayout("", "[][grow][][][][][][][][][][grow]", "[][][grow]"));
		
		JLabel lblNewLabel = new JLabel("Selezionare la query");
		panel.add(lblNewLabel, "cell 4 1");
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection dbConnection=null;
				
				try {
					disableWarning();

					dbConnection= (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
					if(dbConnection!=null)
						System.out.println("Connessione effettuata con successo a: "+DB_URL);            
				}catch(SQLException e1) {
					System.out.println("Connessione non riuscita a: "+DB_URL);
					e1.printStackTrace();
				}
				
				textArea.setText("");
				
				if(comboBox.getSelectedIndex()==0) {
					try {
						textArea.append("Seleziona la matricola,nome e cognome dei dipendenti ordinati per nome,"
						+ "il quale inzia per la lettera m oppure per f ed il cognome che inizia per g"+"\n");
						textArea.append(QueryRaccoltaHub.QUERY1(dbConnection));
						
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				if(comboBox.getSelectedIndex()==1) {
					try {
						textArea.append("Stampare la tipologia dell'attivit� ed il codice del collo,"
								+ "che dovranno essere consegnati nel mese di gennaio 2022"+"\n");
						textArea.append(QueryRaccoltaHub.QUERY2(dbConnection));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				if(comboBox.getSelectedIndex()==2) {
					try {
						textArea.append("Selezionare lo stipendio totale di tutti i dipendenti"+"\n");
						textArea.append(QueryRaccoltaHub.QUERY3(dbConnection));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				if(comboBox.getSelectedIndex()==3) {
					try {
						textArea.append("Per ogni reparto, selezionare la relativa sommma"+" degli stipendi dei dipendenti"+"\n");
						textArea.append(QueryRaccoltaHub.QUERY4(dbConnection));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				
				if(comboBox.getSelectedIndex()==4) {
					try {
						textArea.append("Stampare i nome dei reparti, dove lavorano pi� di 5 dipendenti"+"\n");
						textArea.append(QueryRaccoltaHub.QUERY5(dbConnection));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
				}
				
				if(comboBox.getSelectedIndex()==5) {
					try {
						textArea.append("Elencare il nome del reparto, che possiede lo stipendio maggiore"+"\n");
						textArea.append(QueryRaccoltaHub.QUERY6(dbConnection));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				if(comboBox.getSelectedIndex()==6) {
					try {
						textArea.append(" Selezionare la tipologia degli esercizi commerciali ed il relativo nome dei proprietari,"
								+ "che non hanno merce in consegna per il mese di gennaio dell'anno 2022"+"\n");
						textArea.append(QueryRaccoltaHub.QUERY7(dbConnection));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				if(comboBox.getSelectedIndex()==7) {
					try {
						textArea.append("Selezionare la matricola ed il nome di tutti i dipendenti, che"
								+ "lavorano nel reparto \"Area Clienti\""+"\n");
						textArea.append(QueryRaccoltaHub.QUERY8(dbConnection));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			
			
			
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Query 1", "Query 2", "Query 3", "Query 4", "Query 5", "Query 6", "Query 7", "Query 8"}));
		panel.add(comboBox, "cell 5 1,alignx left");
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, "cell 0 2 12 1,grow");
		panel_1.setLayout(new MigLayout("", "[][][][][grow]", "[][grow]"));
		textArea.setEditable(false);
		
		
		panel_1.add(textArea, "cell 0 0 5 2,grow");
	}

}
