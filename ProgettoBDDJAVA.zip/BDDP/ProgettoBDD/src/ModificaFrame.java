import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ModificaFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextArea textArea = new JTextArea();
	private static final String DB_URL="jdbc:mysql://localhost:3306/hubraccolta";
	private static final String USER="root";
	private static final String PASS="Mercogliano2021!";
	/**
	 * Launch the application.
	 */
	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModificaFrame frame = new ModificaFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModificaFrame() {
		setTitle("Modifica della data di consegna");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 935, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new MigLayout("", "[][][][grow][][]", "[][][][][][grow]"));
		
		JLabel lblNewLabel = new JLabel("IDCollo");
		panel.add(lblNewLabel, "cell 2 3,alignx trailing");
		
		textField = new JTextField();
		panel.add(textField, "flowx,cell 3 3,alignx left");
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Nuova data consegna");
		panel.add(lblNewLabel_1, "cell 3 3");
		
		textField_1 = new JTextField();
		panel.add(textField_1, "cell 3 3,alignx left");
		textField_1.setColumns(10);
		textArea.setEditable(false);
		
		
		panel.add(textArea, "cell 0 4 6 2,grow");
		
		JButton btnNewButton = new JButton("Conferma");
		btnNewButton.addMouseListener(new MouseAdapter() {
		
			public void mouseClicked(MouseEvent e) {
				Connection dbConnection=null;
				textArea.setText("");
				try {
					disableWarning();

					dbConnection= (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
					if(dbConnection!=null)
						System.out.println("Connessione effettuata con successo a: "+DB_URL);            
				}catch(SQLException e1) {
					System.out.println("Connessione non riuscita a: "+DB_URL);
					e1.printStackTrace();
				}
				
				String sql="UPDATE Consegnare SET DataConsegna='"+textField_1.getText()+"'WHERE IDCollo='"+textField.getText()+"';";
				Statement stmt;
				try {
					stmt = dbConnection.createStatement();
					stmt.executeUpdate(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				String result="Select IDCollo,DataConsegna,PIVA FROM Consegnare";
				Statement stmt1;
				try {
					stmt1 = dbConnection.createStatement();
					ResultSet rs=stmt1.executeQuery(result);

					while(rs.next()) {

						textArea.append("IDCollo: "+rs.getString("IDCollo")+" Data consegna: "+rs.getString("DataConsegna")+" PIVA: "+rs.getString("PIVA")+"\n");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				JOptionPane.showMessageDialog(null, "Data di consegna modificata con successo");
				
			}
		});
		panel.add(btnNewButton, "cell 3 3,alignx left");
	}

}
