
import java.sql.*;

public class QueryRaccoltaHub {
	private static final String DB_URL="jdbc:mysql://localhost:3306/hubraccolta";
	private static final String USER="root";
	private static final String PASS="Mercogliano2021!";


	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}

	public static void main(String[] args) throws SQLException {
		Connection dbConnection=null;

		try {
			disableWarning();

			dbConnection= (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
			if(dbConnection!=null)
				System.out.println("Connessione effettuata con successo a: "+DB_URL);            
		}catch(SQLException e) {
			System.out.println("Connessione non riuscita a: "+DB_URL);
			e.printStackTrace();
		}

		QUERY1(dbConnection);
		QUERY2(dbConnection);
		QUERY3(dbConnection);
		QUERY4(dbConnection);
		QUERY5(dbConnection);
		QUERY6(dbConnection);
		QUERY7(dbConnection);
		QUERY8(dbConnection);
	}



	//-- 1) Seleziona la matricola,nome e cognome dei dipendenti ordinati per nome, il quale inzia per la lettera m oppure per f ed il cognome che inizia per g
	public static String QUERY1(Connection dbConnection) throws SQLException{
		String query1="SELECT Matricola,Nome,Cognome FROM Dipendente WHERE (Nome like \"M%\" or Nome like \"F%\") and Cognome like \"G%\" ORDER BY (Nome);";
		String queryRis="";
		Statement stmt=dbConnection.createStatement();
		ResultSet rs=stmt.executeQuery(query1);

		
		while(rs.next()) {
			/*System.out.println("---------------------");
			System.out.println("Matricola: "+rs.getString("Matricola"));*/
			queryRis+="Matricola: "+rs.getString("Matricola")+" Nome: "+rs.getString("Nome")+" Cognome: "+rs.getString("Cognome")+"\n";
			/*System.out.println("Nome: "+rs.getString("Nome"));
			System.out.println("Cognome: "+rs.getString("Cognome"));*/
		}
		return queryRis;

	}

	//-- 2) Stampare la tipologia dell'attivit� ed il codice del collo, che dovranno essere consegnati nel mese di gennaio 2022
	public static String QUERY2(Connection dbConnection) throws SQLException{
		String query2="SELECT E.Tipo,C.IDCollo FROM EsercizioCommerciale as E join Consegnare as C on E.PIVA=C.PIVA WHERE C.DataConsegna>=\"2022-01-01\" and C.DataConsegna<=\"2022-01-31\";";
		String queryRis="";
		Statement stmt=dbConnection.createStatement();
		ResultSet rs=stmt.executeQuery(query2);

		//System.out.println("+++++++++++ Result query 2 ++++++++++++");
		while(rs.next()) {
			//System.out.println("---------------------");
			//System.out.println("Tipo: "+rs.getString("E.Tipo"));
			queryRis+="Tipo: "+rs.getString("E.Tipo")+" IDCollo: "+rs.getString("C.IDCollo")+"\n";
			//System.out.println("IDCollo: "+rs.getString("C.IDCollo"));
		}
		return queryRis;

	}

	//-- 3) Selezionare lo stipendio totale di tutti i dipendenti
	public static String QUERY3(Connection dbConnection) throws SQLException
	{
		String queryRis="";
		String query3="SELECT SUM(D.Stipendio) as \"Stipendio totale\"FROM Dipendente as D;";
		Statement stmt=dbConnection.createStatement();
		ResultSet rs=stmt.executeQuery(query3);
		//System.out.println("+++++++++++ Result query 3 ++++++++++++");
		while(rs.next()) {
			//System.out.println("-------------------------------");
			//System.out.println("Stipendio Totale: "+rs.getString("Stipendio totale"));
			queryRis+="Stipendio totale: "+rs.getString("Stipendio totale")+"\n";
		}
		return queryRis;
	}


	//-- 4) Per ogni reparto, selezionare la relativa sommma degli stipendi dei dipendenti
	public static String QUERY4(Connection dbConnection) throws SQLException{
		String query4="SELECT SUM(D.Stipendio) as \"Stipendio\",R.Nome FROM (Dipendente as D join Lavorare as L on D.Matricola=L.MatricolaDip) join Reparto as R on R.IDReparto=L.IDReparto GROUP BY(R.Nome);";

		Statement stmt=dbConnection.createStatement();
		ResultSet rs=stmt.executeQuery(query4);
		String queryRis="";
		
		System.out.println("+++++++++++ Result query 4 ++++++++++++");
		while(rs.next()) {
			System.out.println("---------------------");
			System.out.println("Stipendio: "+rs.getString("Stipendio"));
			System.out.println("Nome: "+rs.getString("R.Nome"));
			queryRis+=" Nome: "+rs.getString("R.Nome")+" Stipendio: "+rs.getString("Stipendio")+"\n";
		}
		return queryRis;
	}
	
	//-- 5) Stampare i nome dei reparti, dove lavorano pi� di 5 dipendenti
    public static String QUERY5(Connection dbConnection) throws SQLException
    {	
    	String queryRis="";
        String query5="SELECT R.Nome,COUNT(R.IDReparto) as \"Reparto\" FROM  Lavorare as L join Reparto as R on L.IDReparto=R.IDReparto GROUP BY (R.IDReparto) HAVING COUNT(R.IDReparto)>=5;";
        Statement stmt=dbConnection.createStatement();
        ResultSet rs=stmt.executeQuery(query5);
       // System.out.println("+++++++++++ Result query 5 ++++++++++++");
        while(rs.next()) {
            //System.out.println("-------------------------------");
            //System.out.println("Nome Reparto: "+rs.getString("R.Nome"));
            //System.out.println("Numero Dipendenti: "+rs.getString("Reparto"));
            queryRis+="Nome Reparto: "+rs.getString("R.Nome")+" Numero Dipendenti: "+rs.getString("Reparto")+"\n";
        }
        return queryRis;
    }
	
	
	
	
	//-- 6) Elencare il nome del reparto, che possiede lo stipendio maggiore
	public static String QUERY6(Connection dbConnection) throws SQLException{
		String queryRis="";
		String query6="SELECT R.Nome,SUM(D.Stipendio) as \"Stipendio\" FROM (Dipendente as D join Lavorare as L on L.MatricolaDip=D.Matricola) join Reparto as R on R.IDReparto=L.IDReparto GROUP BY(R.IDReparto) HAVING SUM(D.Stipendio) >= ALL (SELECT SUM(D1.Stipendio) FROM Dipendente as D1 join Lavorare as L1 on L1.MatricolaDip=D1.Matricola GROUP BY(L1.IDReparto));";
		Statement stmt=dbConnection.createStatement();
		ResultSet rs=stmt.executeQuery(query6);

		//System.out.println("+++++++++++ Result query 6 ++++++++++++");
		while(rs.next()) {
			System.out.println("---------------------");
			System.out.println("Nome reparto: "+rs.getString("R.Nome"));
			System.out.println("Stipendio: "+rs.getString("Stipendio"));
			queryRis+="Nome reparto: "+rs.getString("R.Nome")+" Stipendio: "+rs.getString("Stipendio")+"\n";
		}
		return queryRis;
	}
	
	//-- 7) Selezionare la tipologia degli esercizi commerciali ed il relativo nome dei proprietari, che non hanno merce in consegna per il mese di gennaio dell'anno 2022
	public static String QUERY7(Connection dbConnection) throws SQLException
    {
		String queryRis="";
        String query7="SELECT E.Tipo,P.Nome FROM EsercizioCommerciale as E join Proprietario as P on P.CF=E.CFProprietario WHERE E.PIVA NOT IN ( SELECT C.PIVA FROM Consegnare as C WHERE  C.PIVA=E.PIVA and C.DataConsegna>=\"2022-01-01\" and C.DataConsegna<=\"2022-01-31\");";
        Statement stmt=dbConnection.createStatement();
        ResultSet rs=stmt.executeQuery(query7);
        //System.out.println("+++++++++++ Result query 7 ++++++++++++");
        while(rs.next()) {
            //System.out.println("-------------------------------");
            //System.out.println("Tipo Attivit�: "+rs.getString("E.Tipo"));
            //System.out.println("Nome Proprietario: "+rs.getString("P.Nome"));
            queryRis+="Tipo Attivit�: "+rs.getString("E.Tipo")+" Nome Proprietario: "+rs.getString("P.Nome")+"\n";
        }
        
        return queryRis;
    }
	
	
	
	//-- 8) Selezionare la matricola ed il nome di tutti i dipendenti, che lavorano nel reparto "Area Clienti"
	public static String QUERY8(Connection dbConnection) throws SQLException{
		String queryRis="";
		String query8="SELECT D.Matricola,D.Nome FROM Dipendente as D WHERE NOT EXISTS (SELECT * FROM Reparto as R WHERE R.Nome=\"Area Clienti\" and NOT EXISTS(SELECT * FROM Lavorare as L WHERE D.Matricola=L.MatricolaDip and L.IDReparto=R.IDReparto));"; 
		Statement stmt=dbConnection.createStatement();
		ResultSet rs=stmt.executeQuery(query8);

		//System.out.println("+++++++++++ Result query 8 ++++++++++++");
		while(rs.next()) {
			//System.out.println("---------------------");
			//System.out.println("Matricola dipedente: "+rs.getString("D.Matricola"));
			//System.out.println("Nome dipendente: "+rs.getString("D.Nome"));
			queryRis+="Matricola dipedente: "+rs.getString("D.Matricola")+" Nome dipendente: "+rs.getString("D.Nome")+"\n";
		}
		return queryRis;
	}
	
}
