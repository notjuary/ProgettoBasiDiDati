import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VisualizzazioneFrame extends JFrame {
	
	private JTextArea textArea = new JTextArea();
	private JPanel contentPane;
	private JTextField textField;
	private static final String DB_URL="jdbc:mysql://localhost:3306/hubraccolta";
	private static final String USER="root";
	private static final String PASS="Mercogliano2021!";
	
	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VisualizzazioneFrame frame = new VisualizzazioneFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VisualizzazioneFrame() {
		setTitle("Visualizzazione dei campi della tabella");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new MigLayout("", "[grow][][grow]", "[][][][grow]"));
		
		JLabel lblNewLabel = new JLabel("Scegliere la tabella ");
		panel.add(lblNewLabel, "cell 1 1,alignx trailing");
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Dipendente", "Reparto", "Lavorare", "Telefono", "Proprietario", "EsercizioCommerciale", "Collo", "Consegnare"}));
		panel.add(comboBox, "cell 2 1,alignx left");
		
		JLabel lblNewLabel_1 = new JLabel("Inserisci i campi da vsiualizzare");
		panel.add(lblNewLabel_1, "cell 1 2,alignx trailing");
		
		textField = new JTextField();
		panel.add(textField, "flowx,cell 2 2,alignx left");
		textField.setColumns(10);
		textArea.setEditable(false);
		
		
		panel.add(textArea, "cell 0 3 3 1,grow");
		
		JButton btnNewButton = new JButton("Inserisci");
		btnNewButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				Connection dbConnection=null;
				textArea.setText("");
				
				try {
					disableWarning();

					dbConnection= (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
					if(dbConnection!=null)
						System.out.println("Connessione effettuata con successo a: "+DB_URL);            
				}catch(SQLException e1) {
					System.out.println("Connessione non riuscita a: "+DB_URL);
					e1.printStackTrace();
				}
				
				
				String sceltaTabella=(String) comboBox.getSelectedItem();
				
				try {
					String query="SELECT "+textField.getText()+" FROM "+sceltaTabella;
					String split[]=textField.getText().split(",");
					java.sql.Statement stmt1= dbConnection.createStatement();
					ResultSet rs=stmt1.executeQuery(query);
					while(rs.next()) {
						for(int i=0;i<split.length;i++) {
							textArea.append(split[i]+": "+rs.getString(split[i])+"\n");
						}
					}
				}catch(SQLException ex) {
					ex.printStackTrace();
				}
		        
			
			
			
			}
		});
		panel.add(btnNewButton, "cell 2 2");
		
		
	}

}
